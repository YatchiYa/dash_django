from channels.routing import ProtocolTypeRouter

application = ProtocolTypeRouter({
    
})