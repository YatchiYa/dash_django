

from base64 import b64encode

import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
import plotly.express as px
from numpy.random import seed, rand
import numpy as np

from datetime import datetime, timedelta

import pandas as pd
import pandas_datareader as pdr
import plotly.graph_objects as go




def crypto():
    CRYPTO = 'BTC'
    #CURRENCY = 'EUR'


    CRYPTOS = ['BTC','ETH','LTC']
    CURRENCY = 'EUR'

    def getData(cryptocurrency):
        now = datetime.now()
        current_date = now.strftime("%Y-%m-%d")
        last_year_date = (now - timedelta(days = 365)).strftime("%Y-%m-%d")

        start = pd.to_datetime(last_year_date)
        end = pd.to_datetime(current_date)

        data = pdr.get_data_yahoo(f'{cryptocurrency}-{CURRENCY}', start, end)

        return data


    crypto_data = getData(CRYPTO)

    # Candlestick
    fig = go.Figure(
        data = [
            go.Candlestick(
                x = crypto_data.index,
                open = crypto_data.Open,
                high = crypto_data.High,
                low = crypto_data.Low,
                close = crypto_data.Close
            ),
            go.Scatter(
                x = crypto_data.index, 
                y = crypto_data.Close.rolling(window=20).mean(),
                mode = 'lines', 
                name = '20SMA',
                line = {'color': '#ff006a'}
            ),
            go.Scatter(
                x = crypto_data.index, 
                y = crypto_data.Close.rolling(window=50).mean(),
                mode = 'lines', 
                name = '50SMA',
                line = {'color': '#1900ff'}
            )
        ]
    )

    fig.update_layout(
        title = f'The Candlestick graph for {CRYPTO}',
        xaxis_title = 'Date',
        yaxis_title = f'Price ({CURRENCY})',
        xaxis_rangeslider_visible = False
    )
    fig.update_yaxes(tickprefix='€')


    crypto_data = {crypto:getData(crypto) for crypto in CRYPTOS}
    # crypto_data = dict()
    # for crypto in CRYPTOS:
    #     crypto_data[crypto] = getData(crypto)

    fig2 = go.Figure()

        # Scatter
    for idx, name in enumerate(crypto_data):
            fig2 = fig2.add_trace(
                go.Scatter(
                    x = crypto_data[name].index,
                    y = crypto_data[name].Close,
                    name = name,
                )
            )

    fig2.update_layout(
            title = 'The Correlation between Different Cryptocurrencies',
            xaxis_title = 'Date',
            yaxis_title = f'Closing price ({CURRENCY})',
            legend_title = 'Cryptocurrencies',
            xaxis_rangeslider_visible = True
        )
    fig2.update_yaxes(type='log', tickprefix='€')

    return fig, fig2





